step 1: extract all files
step 2: move the folder named "python" to your Documents folder
step 3: if you do not have python already installed double click the file named "python-3.12.4-amd64"
step 3: if you do not have "getpass4" installed double click the file named "install getpass4 (important for password security)"
step 4: change the contents of the file named "password_default_is_1234" to be whatever you want (must be one line) and encrypt it if you feel it is necessary
step 5: double click the file named "run code" once you've done steps 1-4 you do not need to do them again you just need to run the "run code" file
step 6: right click the "run code" file and click "Create Shortcut" and name your shortcut and then move it to the Desktop by dragging to the Desktop folder