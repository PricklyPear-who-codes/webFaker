import os
import datetime
import settings
from getpass4 import getpass

def start():
    def setup():
        global password
        with open("password_default_is_1234.txt", "r") as passwordOpened:
            password = passwordOpened.readlines()

    def loop():
        userInpt = getpass("Password: ")
        if userInpt != str(password[0]):
            settings.clear()
        else:
            settings.clear()
            settings.start()

    setup()

    while True:
        loop()
