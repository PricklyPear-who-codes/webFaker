import os
import datetime
import locked_username as username

def clear():
    os.system('cls')

def start():
    def check(com):
        broken = com.split()
        #quit command
        if broken[0] == "quit":
            quit(broken[1])
        #print command
        if com.startswith("print "):
            print(com.split("print ")[1])
        #get the current dir
        if com.startswith("getCurrDir"):
            print(os.getcwd() + ">")
        if com.startswith("changeDir "):
            os.system(f"cd {com.split('changeDir ')[1]}")
            print(f"Changed to {com.split('changeDir ')[1]}")
        #open app command
        if com.startswith("openFile "):
            with open(f"{com.split('openFile ')[1]}", "r") as file:
                lines = file.readlines()
                for line in lines:
                    print(line.strip())
        #clear command
        if com == "clear":
            clear()
        #create file command
        if com.startswith("createFile "):
            with open(f"{com.split('createFile ')[1]}", "w") as file:
                file.write("Empty File")
        #delete file command
        if com.startswith("deleteFile "):
            if os.path.isfile(com.split("deleteFile ")[1]):
                os.remove(com.split("deleteFile ")[1])
            else:
                print(f"Error: {com.split('deleteFile ')[1]} not found")
        #lock function
        if com == "lock":
            clear()
            username.start()
            
    
    def loop():
        command = input(":")
        check(command)

    while True:
        loop()
